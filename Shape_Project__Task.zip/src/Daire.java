public class Daire {

    // TODO Bu class doldurunuz
}
