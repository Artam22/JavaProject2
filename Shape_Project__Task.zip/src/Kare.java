public class Kare {

    // TODO Bu class doldurunuz
}
