public class Ucgen {

    // TODO Bu class doldurunuz


}
