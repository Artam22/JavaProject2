public class Dikdortgen {

    // TODO Bu class doldurunuz
}
