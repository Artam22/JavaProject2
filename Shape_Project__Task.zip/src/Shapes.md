### *   "Işlemler" adlı bir arayüz (interface) uygulayarak çeşitli geometrik şekillerin (Kare, Dikdörtgen, Daire ve Üçgen) alanını ve çevresini hesaplayan bir Java programı yazın.
### *   Program, kullanıcının hesaplama yapmak istediği yöntemi seçme olanağı sunmalıdır.
### *   Sağlanan çözüm, çeşitli şekillerin alanını ve çevresini hesaplamak için arayüz (interface) işlemlerinin `alanHesapla()` ve `cevreHesapla()` yöntemleriyle kullanımını içermelidir.
### *   Kare, Dikdörtgen, Daire ve Üçgen sınıfları, "`Islemler`" arayüzünü (interface) uygular ve alan ile çevre hesaplamasına yönelik ilgili uygulamaları sağlar.
### *   Runner sınıfı, kullanıcının istenilen şekli seçmesine ve alan ile çevre hesaplamalarını gerçekleştirmesine olanak tanıyan ana yöntemi (`main()` method) içerir.

![img.png](resources/img.png)

