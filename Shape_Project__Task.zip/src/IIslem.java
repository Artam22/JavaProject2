public interface IIslem {

    // TODO Bu class doldurunuz
}
